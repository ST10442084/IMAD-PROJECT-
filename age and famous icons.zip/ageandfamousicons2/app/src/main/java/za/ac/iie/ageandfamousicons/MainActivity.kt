package za.ac.iie.ageandfamousicons

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

abstract class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var outputText = findViewById<TextView>(R.id.outputText)

        val generateButton = findViewById<Button>(R.id.generateButton)

        val ageButton = findViewById<EditText>(R.id.ageButton)

        generateButton.setOnClickListener(){

            val age = ageButton.text.toString().toIntOrNull()

            if (age != null && age in 20..100){
                val matchedPerson = (age)
                outputText.text = "Iconic person died at age $age: $matchedPerson"

            } else {
                outputText.text = "Please enter valid age betwwen 20 and 100."
            }


        }


        }
           private fun matchedAgeToIconicPerson(age: Int) : String {
               // This is a simplified example, you can replace it with your own data
               return when (age) {
                   in 20..30 -> "Cameron Boyce"
                   in 31..40->  "Bruce Lee"
                   in 41..50->  "Chester Bennington"
                   in 51..60->  "Babe Ruth"
                   in 61..70->  "Tony Scott"
                   in 71..80->  "John Wayne"
                   in 81..90->  "Paul Newman"
                   else -> "Nelson Mandela"
               }
           }

}





